import os, sys, gzip
import getopt
import time
import subprocess
import re
from collections import defaultdict
import random
import string
import pysam

class baseinfo:
	def __init__(self):
		self.configdist = {}

	def get_config(self, configFile):
		o_config = open (configFile, 'r')
		for config_line in o_config:
			config_line = config_line.strip()
			if len(config_line) == 0:
				pass
			elif config_line.startswith('#'):
				pass
			else:
				(name, path) = re.split(" = ", config_line)
				name = name.strip()
				path = path.strip()
				path = path.replace("'", "")
				path = path.replace('"', '')

				self.configdist[name] = path
#				print (name, path)
		o_config.close()

	def get_path(self, name_variable):
		if name_variable in self.configdist:
			ABS_PATH = self.configdist[name_variable]
			if ABS_PATH == "None":
				ABS_PATH = " "
			return ABS_PATH
		else:
			sys.stderr.write("ERROR - %s - %s is empty, please check the config file you inputted!\n" % (time.asctime(), name_variable))
			sys.exit(-1)

	def Samtools(self):
		abs_path = self.get_path('samtools')
		return abs_path

	def Barcode_index(self):
		abs_path = self.get_path('barcode_index')
		return abs_path

	def Genomesize(self):
		abs_path = self.get_path('genomesize')
		return abs_path

def check_info(result, attribute):
	if attribute == "file":
		if os.path.isfile(result) == False:
			sys.stderr.write("[ %s ] %s does not exist!\n" % (time.asctime(), result))
			sys.exit(-1)
	elif attribute == "dir":
		if os.path.isdir(result) == False:
			os.makedirs(result)

class CFCR:
	def find_samtools_version(self, samtools_path, tmpdir):
		randomstring = ''.join(random.sample(string.ascii_letters + string.digits, 8))
		tmpshell = tmpdir + "/" + randomstring + ".sh"
		tmplog = tmpdir + "/" + randomstring + ".log"
		wtmpshell = open(tmpshell, 'w')
		shell_line = " ".join([samtools_path, "2>", tmplog, "\n"])
		wtmpshell.write(shell_line)
		wtmpshell.close()
		subprocess.call(["sh", tmpshell])

		sv = 0
		rlog = open(tmplog, 'r')
		for log in rlog:
			if re.search("Version", log):
				loginfo = re.split('\s', log)
				sv = (re.split('\.', loginfo[1]))[0]
		rlog.close()
		subprocess.call(["rm", tmpshell, tmplog])
		return(int(sv))

	def bam2list(self, baminfo, rsorted_sam):
		cigar_dict = {0:"M", 1:"I", 2:"D", 3:"N", 4:"S", 5:"H", 6:"P", 7:"=", 8:"X"}
		infolist = list()
		infolist.append(baminfo.query_name)
		infolist.append(str(baminfo.flag))
		infolist.append(rsorted_sam.get_reference_name(baminfo.reference_id))
		infolist.append(str(baminfo.reference_start+1))
		infolist.append(str(baminfo.mapping_quality))
		cigar = 0
		k = 1
		for c in range(0, len(baminfo.cigar)):
			if baminfo.cigar[c][0] in cigar_dict:
				if cigar == 0:
					cigar = str(baminfo.cigar[c][1]) + cigar_dict[baminfo.cigar[c][0]]
				else:
					cigar = cigar + str(baminfo.cigar[c][1]) + cigar_dict[baminfo.cigar[c][0]]
			else:
				k = 0
		if len(baminfo.cigar) == 0:
			infolist.append("*")
		else:
			if k == 1:
				infolist.append(cigar)
			else:
				infolist.append(baminfo.cigar)
		if baminfo.next_reference_id == baminfo.reference_id:
			infolist.append("=")
		else:
			infolist.append(rsorted_sam.get_reference_name(baminfo.next_reference_id))
		infolist.append(str(baminfo.next_reference_start+1))
		infolist.append(str(baminfo.template_length))
		infolist.append(baminfo.query_sequence)

		query_qualities = 0
		for q in range(0,len(baminfo.query_qualities)):
			if query_qualities == 0:
				query_qualities = chr(baminfo.query_qualities[q] + 33)
			else:
				query_qualities = query_qualities + chr(baminfo.query_qualities[q] + 33)
		infolist.append(query_qualities)

		for tag in baminfo.tags:
			tag_list = list()
			tag_list.append(tag[0])
			marker = "i"
#			if re.match(r"^[!-~]$", str(tag[1])):
#				marker = "A"
			if re.match(r"^[-+]?[0-9]+$", str(tag[1])):
				marker = "i"
			elif re.match(r"^[-+]?[0-9]*\.?[0-9]+([eE][-+]?[0-9]+)?$", str(tag[1])):
				marker = "f"
			elif re.match(r"^[ !-~]*$", str(tag[1])):
				marker = "Z"
			elif re.match(r"^([0-9A-F][0-9A-F])*$", str(tag[1])):
				marker = "H"
			elif re.match(r"^[cCsSiIf](,[-+]?[0-9]*\.?[0-9]+([eE][-+]?[0-9]+)?)+$", str(tag[1])):
				marker = "B"
			else:
				marker = "A"  ## re.match(r"^[!-~]$", str(tag[1])):
			if tag[0] == "NM":
				marker = "i"
			tag_list.append(marker)
			tag_list.append(str(tag[1]))
			tag_info = ":".join(tag_list)
			infolist.append(tag_info)
		infolist_tostr = "\t".join(infolist)
		return(infolist_tostr)

	def split_and_sort_sam(self, sorted_bam, samtools_path, outdir = './'):
		shelldir = os.path.join(outdir, "shell")
		check_info(shelldir, "dir")
		tmpshell = outdir + "/shell/check_sort.sh"
		wtmpshell = open(tmpshell, 'w')
		tmpheader = tmpshell + ".tmp.header"
		shell_line = " ".join([samtools_path, "view -H", sorted_bam, "| grep coordinate >", tmpheader, "\n"])
		wtmpshell.write(shell_line)
		wtmpshell.close()
		subprocess.call(["sh", tmpshell])
		subprocess.call(["rm", tmpshell])

		if os.path.getsize(tmpheader):
			sys.stderr.write("%s has been sorted!\n" % sorted_bam)
		else:
			sys.stderr.write("%s has not been sorted, and would be sorted before calculating CF/CR!\n" % sorted_bam)

			tmpshell = shelldir + "/sort_bam.sh"
			wtmpshell = open(tmpshell, 'w')
			sv = self.find_samtools_version(samtools_path, outdir)
			if sv == 0:
				shell_line = " ".join([samtools_path, "sort -m 2G", sorted_bam, sorted_bam + ".sorted\n"])
			else:
				shell_line = " ".join([samtools_path, "sort -m 2G -o", sorted_bam + ".sorted.bam -T", sorted_bam, sorted_bam, "\n"])
			wtmpshell.write(shell_line)
			shell_line = " ".join(["mv", sorted_bam + ".sorted.bam", sorted_bam, "\n"])
			wtmpshell.write(shell_line)
			wtmpshell.close()
			subprocess.call(["sh", tmpshell])
			subprocess.call(["rm", tmpshell])

		rsorted_sam = pysam.AlignmentFile(sorted_bam, 'rb')
		duplicated_bam = os.path.join(outdir, "duplicated.bam")
		unmap_bam = os.path.join(outdir, "unmapped.bam")
		additional_bam = os.path.join(outdir, "additional.bam")
		barcode_name_bam = os.path.join(outdir, "barcode_name.bam")
		wduplicated_bam = pysam.AlignmentFile(duplicated_bam, 'wb', template = rsorted_sam)
		wunmap_bam = pysam.AlignmentFile(unmap_bam, 'wb', template = rsorted_sam)
		wadditional_bam = pysam.AlignmentFile(additional_bam, 'wb', template = rsorted_sam)
		wbarcode_name_bam = pysam.AlignmentFile(barcode_name_bam, 'wb', template = rsorted_sam)

		for saminfo in rsorted_sam:
			chr_real_name = "chr1"
			if saminfo.reference_id >= 0:
				chr_real_name = rsorted_sam.get_reference_name(saminfo.reference_id)
			if saminfo.flag > 1000:
				wduplicated_bam.write(saminfo)	## duplication reads
#			elif chr_real_name == "*":
#				wunmap_bam.write(saminfo)	## unmmpaed reads
			elif len(chr_real_name) > 5:
				wadditional_bam.write(saminfo)	## additional chromosomes that not include chr1-22, X, Y, M
			else:
				newinfo = pysam.AlignedSegment()
				newinfo = saminfo
				newtags = list()
				for eachtag in newinfo.tags:
					if eachtag[0] == "BC":
						newinfo.query_name = eachtag[1] + "_" + newinfo.query_name
				wbarcode_name_bam.write(newinfo)
		wduplicated_bam.close()
		wunmap_bam.close()
		wadditional_bam.close()
		wbarcode_name_bam.close()

		sort_shell = outdir + "/shell/sort_barcode_bam.sh"
		wsort_shell = open(sort_shell, 'w')
		sv = self.find_samtools_version(samtools_path, outdir)
		barcode_name_sorted_bam = os.path.join(outdir, "barcode_name.sorted.bam")
		if sv == 0:
			shell_line = " ".join([samtools, "sort -n -m 3G", barcode_name_bam, os.path.join(outdir, "barcode_name.sorted")]) + "\n"
		else:
			shell_line = " ".join([samtools, "sort -n -m 3G -o", barcode_name_sorted_bam, barcode_name_bam]) + "\n"
		wsort_shell.write(shell_line)
		shell_line = "rm " + barcode_name_bam + "\n"
		wsort_shell.write(shell_line)
		wsort_shell.close()
		subprocess.call(["sh", sort_shell])

		return(barcode_name_sorted_bam)

	def barcode_calculate(self, molecule_id, rbam, wbam, wcsv, mol_length, baminfo_list):
		readid_dict = dict()
		each_barcode_sequence = "A"
		for each_baminfo in baminfo_list:
			each_baminfo_list = re.split("\t", each_baminfo)
			each_barcode_sequence = (re.split("_", each_baminfo_list[0]))[0]
			query_name = (re.split("_", each_baminfo_list[0]))[1]
			readid = query_name
			if readid not in readid_dict:
				_info_ = each_baminfo_list[2] + "############" + each_baminfo
				readid_dict[readid] = _info_
			else:
				if each_baminfo_list[0] != (re.split("############", readid_dict[readid]))[0]:
					del readid_dict[readid]
				else:
					readid_dict[readid] = readid_dict[readid] + "############" + each_baminfo

		chrinfo_dict = defaultdict(dict)
		for readid in readid_dict.keys():
			readinfo_list = re.split("############", readid_dict[readid])
			each_baminfo_list = re.split("\t", readinfo_list[1])
			chrid = each_baminfo_list[2]
			pos = each_baminfo_list[3]
			if pos not in chrinfo_dict[chrid]:
				chrinfo_dict[chrid][pos] = "############".join(readinfo_list[1:])
			else:
				pz = pos - 200
				while(pz < pos+200):
					if pz not in chrinfo_dict[chrid]:
						chrinfo_dict[chrid][pz] = "############".join(readinfo_list[1:])
						pz = pos + 500
					else:
						pz += 1

		CR_dict = dict()
		molecule_dict = defaultdict(list)
		mi = 0
		for chrinfo in chrinfo_dict.keys():
			each_chr_dict = chrinfo_dict[chrinfo]
			sorted_dict = sorted(each_chr_dict.items(), key=lambda each_chr_dict:each_chr_dict[0], reverse = False)
			for pos in sorted_dict:
				print(pos[0] + "\t" + pos[1])
				sys.exit(-1)
				each_baminfo_list = re.split("\t", sorted_dict[pos][0])
				baminfo2 = 0
				readid = each_baminfo_list[0]
				small_cr = len(each_baminfo_list[9])
				start = each_baminfo_list[3]
				end = start + len(each_baminfo_list[9])
				if len(sorted_dict[pos]) == 2:
					each_baminfo_list2 = re.split("\t", sorted_dict[pos][1])
					small_cr += len(each_baminfo_list2[9])
					start = min(start, each_baminfo_list2[3])
					end = max(end, each_baminfo_list2[3] + len(each_baminfo_list2[9]))
				CR_dict[readid] = small_cr
				small_cf = end - start + 1
				if small_cf < 50000:
					if mi not in molecule_dict:
						molecule_dict[mi][0] = start
						molecule_dict[mi][1] = end
						molecule_dict[mi][2].append(sorted_dict[pos][0])
						if len(sorted_dict[pos]) > 1:
							molecule_dict[mi][2].append(sorted_dict[pos][1])
					else:
						if (molecule_dict[mi][1] < start and (start - molecule_dict[mi][1] > 50000)) or (molecule_dict[mi][0] > end and (molecule_dict[mi][0] - end > 50000)):
							mi += 1
						else:
							start = min(start, molecule_dict[mi][0])
							end = max(end, molecule_dict[mi][1])
						molecule_dict[mi][0] = start
						molecule_dict[mi][1] = end
						molecule_dict[mi][2].append(sorted_dict[pos][0])
						if len(sorted_dict[pos]) > 1:
							molecule_dict[mi][2].append(sorted_dict[pos][1])

		#each_barcode_sequence
		molecule_num_in_each_barcode = len(molecule_dict)
		if molecule_num_in_each_barcode > 2:
			for realmi in molecule_dict.keys():
				Molecule_len = molecule_dict[realmi][1] - molecule_dict[realmi][0] + 1
				if Molecule_len < mol_length:
					del molecule_dict[realmi]

		molecule_num_in_each_barcode = len(molecule_dict)
		if molecule_num_in_each_barcode > 2:
			for realmi in molecule_dict.keys():
				molecule_id += 1
				Chrid = molecule_dict[realmi][2][2]
				Start_pos = str(molecule_dict[realmi][0])
				End_pos = str(molecule_dict[realmi][1])
				Molecule_len = molecule_dict[realmi][1] - molecule_dict[realmi][0] + 1
				reads_num = len(molecule_dict[realmi]) - 2
				Total_length_reads = 0
				for i in range(2,len(molecule_dict[realmi])):
					baminfo = molecule_dict[realmi][i]
#					MI_tag = ("MI", each_barcode_sequence + "-" + str(molecule_id))
					MI_tag = "MI:Z:" + each_barcode_sequence + "-" + str(molecule_id)
					baminfo = baminfo + "\t" + MI_tag
					wbam.write(baminfo)

					Total_length_reads += len((re.split("\t", baminfo))[9])
				Depth = round(1.0 * Total_length_reads / Molecule_len, 2)
				csvinfo = ",".join([str(molecule_id), each_barcode_sequence, Chrid, Start_pos, End_pos, str(Molecule_len), str(reads_num), str(Total_length_reads), str(Depth)]) + "\n"
				wcsv.write(csvinfo)

		return(molecule_id)

	def calculate(self, sorted_by_barcode_bam, outdir, samtools_path, molecule_length):
		statistics_report_dir = os.path.join(outdir, "statistics")
		check_info(statistics_report_dir, "dir")

		merge_molecule_file = os.path.join(statistics_report_dir, "fragment_info.csv")
		wmerge_molecule_file = open(merge_molecule_file, 'w')
		wmerge_molecule_file.write('Molecule_id'+','+'Barcode_seq'+','+'Chr'+','+'Start_pos'+','+'End_pos'+','+'Molecule_len'+','+'# of reads'+','+'Total_length_reads'+','+'Depth'+'\n')

		rsorted_by_barcode_bam = pysam.AlignmentFile(sorted_by_barcode_bam, 'rb')
		outbam = outdir + "/molecule_filtered.bam"
		woutbam = pysam.AlignmentFile(outbam, 'wb', template = rsorted_by_barcode_bam)

		barcode_sequence = "A"
		mol_id = 0
		barcode_baminfo_list = list()
		for saminfo in rsorted_by_barcode_bam:
			new_barcode = (re.split("_", saminfo.query_name))[0]
			if new_barcode != barcode_sequence:
				if barcode_sequence != "A":
					mol_id = self.barcode_calculate(mol_id, rsorted_by_barcode_bam, woutbam, wmerge_molecule_file, molecule_length, barcode_baminfo_list)
				barcode_baminfo_list = list()
				barcode_sequence = new_barcode
				barcode_baminfo_list.append(self.bam2list(saminfo, rsorted_by_barcode_bam))
			else:
				barcode_baminfo_list.append(self.bam2list(saminfo, rsorted_by_barcode_bam))
		mol_id = self.barcode_calculate(mol_id, rsorted_by_barcode_bam, woutbam, wmerge_molecule_file, molecule_length, barcode_baminfo_list)

		wmerge_molecule_file.close()
		rsorted_by_barcode_bam.close()
		woutbam.close()

		outsortbam = outbam.replace("molecule_filtered.bam", "molecule_filtered.sorted.bam")
		outsortbam_prefix = outsortbam.replace("molecule_filtered.sorted.bam", "molecule_filtered.sorted")
		tmpshell = outdir + "/sort_final_bam.sh"
		wtmpshell = open(tmpshell, 'w')
		sv = self.find_samtools_version(samtools_path, outdir)
		if sv == 0:
			shell_line = " ".join([samtools_path, "sort -m 2G", outbam, outsortbam_prefix + "\n"])
		else:
			shell_line = " ".join([samtools_path, "sort -m 2G -o", outsortbam, outbam + "\n"])
		wtmpshell.write(shell_line)
		wtmpshell.close()
		subprocess.call(["sh", tmpshell])
		subprocess.call(["rm", tmpshell])

		return(outsortbam, merge_molecule_file)

	def calculate2(self, csvfile, statistics_report_dir):
		CFCR_stat = os.path.join(statistics_report_dir, "CFCR.stat")
		NFP_summary = os.path.join(statistics_report_dir, "NFP_summary.xls")
#		W_MuFL_summary = os.path.join(statistics_report_dir, "weight_MuFL.xls")
		MuFL_summary = os.path.join(statistics_report_dir, "Unweight_MuFL.xls")
		rcsvfile = open(csvfile, 'r')
		wCFCR_stat = open(CFCR_stat, 'a')
		wNFP_summary = open(NFP_summary, 'w')
		wMuFL_summary = open(MuFL_summary, 'w')
#		wW_MuFL_summary = open(W_MuFL_summary, 'w')
		NFP_dict = dict()
		molecule_len_dict = dict()
		for csvinfo in rcsvfile:
			csvinfolist = re.split(",", csvinfo.strip())
			if csvinfolist[0] != "Molecule_id":
				if csvinfolist[1] not in NFP_dict:
					NFP_dict[csvinfolist[1]] = 1
				else:
					NFP_dict[csvinfolist[1]] += 1

				mst = int(int(csvinfolist[5]) / 1000)
				if mst not in molecule_len_dict:
					molecule_len_dict[mst] = 1
				else:
					molecule_len_dict[mst] +=1
		rcsvfile.close()

		molecule_count = 0
		barcode_count = 0
		sorted_NFP_dict = sorted(NFP_dict.items(), key=lambda NFP_dict:NFP_dict[1], reverse = True)
		for sortedNFP in sorted_NFP_dict:
			info = str(sortedNFP[0]) + "\t" + str(sortedNFP[1]) + "\n"
			wNFP_summary.write(info)
			barcode_count += 1
			molecule_count += int(sortedNFP[1])
		wNFP_summary.close()

		barcode_average_molecule = round(1.0 * molecule_count / barcode_count, 2)
		CFCR_stat_info = "\nNFP:\t" + str(barcode_average_molecule) + "\n"
		wCFCR_stat.write(CFCR_stat_info)

		total_molecule_length = 0
		total_molecule_num = 0
		sorted_molecule_len_dict = sorted(molecule_len_dict.items(), key=lambda molecule_len_dict:molecule_len_dict[0], reverse = False)
		for sortedmoleculelen in sorted_molecule_len_dict:
			info = str(sortedmoleculelen[0]) + "\t" + str(sortedmoleculelen[1]) + "\n"
			total_molecule_length += int(sortedmoleculelen[0]) * int(sortedmoleculelen[1])
			total_molecule_num += 1
			wMuFL_summary.write(info)
		wMuFL_summary.close()
#		wW_MuFL_summary.close()
		Un_MuFL = round((total_molecule_length / total_molecule_num), 2)
		CFCR_stat_info = "Unweighted MuFL:\t" + str(Un_MuFL) + "\n"
		wCFCR_stat.write(CFCR_stat_info)

		molecule_length_N50 = 0
		for sortedmoleculelen in sorted_molecule_len_dict:
			if molecule_length_N50 != 1:
				for e in range(0, int(sortedmoleculelen[1])):
					r1 = molecule_length_N50 / total_molecule_length
					r2 = (molecule_length_N50 + int(sortedmoleculelen[0])) / total_molecule_length
					molecule_length_N50 += int(sortedmoleculelen[0])
					if r1 < 0.5 and r2 >= 0.5:
						CFCR_stat_info = "Weighted MuFL:\t" + str(sortedmoleculelen[0]) + "\n"
						wCFCR_stat.write(CFCR_stat_info)
						molecule_length_N50 = 1
		wCFCR_stat.close()
		
		return(statistics_report_dir)

def usage():
	calculation_usage = \
	'''
	calculate linked read statistics
	Version: 1.0.0
	Dependents: Python (>=3.0), SAMtools
	Last Updated Date: 2017-11-15

	Usage: python calculate.py [options]

	Basic Options:
		-i --input, path of input bam
		-o --outputdir, the path of output
		-c --config, the path of configuration file [default: ./config/Basic.config]
		-h --help, print help info
	Advanced Options:
		-m --minlen, minimum molecule length [default: 500bp]

	'''
	print(calculation_usage)

if __name__ == '__main__':
	if len(sys.argv) < 5:
		usage()
		sys.exit(-1)

	inputbam = None
	outputdir = None
	ConfigFile = None
	Molecule_length = 500
	opts, args = getopt.gnu_getopt(sys.argv[1:], 'i:o:m:c:h:', ['input', 'outputdir', 'minlen', 'config', 'help'])
	for o, a in opts:
		if o == '-i' or o == '--input':
			inputbam = a
		if o == '-o' or o == '--outputdir':
			outputdir = a
		if o == '-m' or o == '--minlen':
			Molecule_length = int(a)
		if o == '-c' or o == '--config':
			ConfigFile = a
		if o == '-h' or o == '--help':
			usage()
			sys.exit(-1)

	if ConfigFile == None or os.path.exists(ConfigFile) == False:
		sys.stderr.write("configuration file has not been provided or does not exist, Please create it using 'python LRTK-SEQ.py Config'\n")
		sys.exit(-1)
	
	PLOT_script = os.path.join(os.path.dirname(os.path.abspath(sys.argv[0])), "plot.py")
	if os.path.exists(PLOT_script) == False:
		sys.stderr.write("%s does not exist, the software package might not been downloaded perfectly!" % PLOT_script)
		sys.exit(-1)

	G = baseinfo()
	G.get_config(ConfigFile)
	samtools = G.Samtools()
	genomesize = G.Genomesize()
	barcode_index = G.Barcode_index()

	C = CFCR()
	samdir = os.path.dirname(os.path.abspath(inputbam))
	sys.stderr.write("[ %s ] split sam file by chromosome, sort sam file by barcode ... \n" % time.asctime())
	modified_bam = C.split_and_sort_sam(inputbam, samtools, samdir)
#	sys.stderr.write("[ %s ] splited and sorted sam file list: %s \n\n" % (time.asctime(), Samfilepath))

#	sys.stderr.write("[ %s ] calculating CF, CR, NFP and MuFL ... \n" % time.asctime())
	report_dir = samdir + "/statistics"
	(filtered_bam, stat_csv) = C.calculate(modified_bam, samdir, samtools, Molecule_length)    #stat_csv = report_dir + "/fragment_info.csv"
	sys.stderr.write("[ %s ] statistical results have been generated in directory: %s \n" % (time.asctime(), report_dir))

	report_dir = C.calculate2(stat_csv, report_dir)
#	subprocess.call(["python", PLOT_script, stat_csv, report_dir])
	sys.stderr.write("[ %s ] figures have been plotted in %s !\n\n" % (time.asctime(), report_dir))
